Rm *.o

make