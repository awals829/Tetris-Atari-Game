Rm *.o 

make