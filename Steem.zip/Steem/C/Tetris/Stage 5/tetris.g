Rm *.o

make tetris